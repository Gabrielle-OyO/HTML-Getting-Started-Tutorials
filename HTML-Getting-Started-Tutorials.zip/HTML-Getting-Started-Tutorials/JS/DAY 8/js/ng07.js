
var app=angular.module('myApp', []);

app.controller('DirectiveController', ['$scope', function($scope){

	
}])